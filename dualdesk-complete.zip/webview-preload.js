// ─────────────────────────────────────────────────────────────────────────────
//  webview-preload.js  —  Runs inside every <webview> renderer process
//
//  This script is injected into WhatsApp Web, Instagram, etc. before their
//  own JavaScript runs. It intercepts the browser's Notification API so we
//  can relay new-message alerts to the host page (renderer.js), which then
//  sends them to the main process to display as native OS notifications.
//
//  It also ensures that web apps always see Notification.permission as
//  "granted" so they don't ask the user repeatedly.
// ─────────────────────────────────────────────────────────────────────────────

'use strict';

const { ipcRenderer } = require('electron');

// ─── Notification API interception ───────────────────────────────────────────

const _Original = window.Notification;

/**
 * DualDeskNotification wraps the original Notification constructor.
 * When WhatsApp (or any web app inside the webview) calls:
 *
 *   new Notification("New message from Alice", { body: "Hey!" })
 *
 * We:
 *  1. Relay the title/body/icon to the host page via ipcRenderer.sendToHost()
 *  2. Still create the original Notification so the web app's callbacks fire
 */
function DualDeskNotification(title, options = {}) {
  // Send to the host renderer page (renderer.js listens on the <webview> element)
  ipcRenderer.sendToHost('webview:notification', {
    title: String(title  || ''),
    body:  String(options.body  || ''),
    icon:  options.icon  || '',
    tag:   options.tag   || '',
  });

  // Construct the real notification so the web app gets its .onclick etc.
  return new _Original(title, options);
}

// ── Copy static members ──────────────────────────────────────────────────────

// Always report permission as granted so apps don't disable notifications
Object.defineProperty(DualDeskNotification, 'permission', {
  get: () => 'granted',
  configurable: true,
});

// requestPermission() should immediately resolve with "granted"
DualDeskNotification.requestPermission = () => Promise.resolve('granted');

// Preserve prototype chain so instanceof checks pass
Object.setPrototypeOf(DualDeskNotification,          _Original);
Object.setPrototypeOf(DualDeskNotification.prototype, _Original.prototype);

// ── Replace window.Notification ─────────────────────────────────────────────

try {
  Object.defineProperty(window, 'Notification', {
    value:        DualDeskNotification,
    writable:     true,
    configurable: true,
    enumerable:   false,
  });
} catch (_err) {
  // Fallback for environments where defineProperty is restricted
  window.Notification = DualDeskNotification;
}

// ─── Service Worker notification interception ─────────────────────────────────
//
//  WhatsApp Web also sends notifications through a Service Worker via the
//  Push API. We patch ServiceWorkerRegistration.showNotification to catch
//  those as well.

if ('serviceWorker' in navigator) {
  const _swProto = ServiceWorkerRegistration.prototype;
  const _origShow = _swProto.showNotification;

  _swProto.showNotification = function (title, options = {}) {
    ipcRenderer.sendToHost('webview:notification', {
      title: String(title || ''),
      body:  String(options.body  || ''),
      icon:  options.icon  || '',
      tag:   options.tag   || '',
    });
    return _origShow.call(this, title, options);
  };
}

// ─── Console marker ───────────────────────────────────────────────────────────
//
//  Makes it easy to confirm the preload ran when debugging DevTools.
//  Press Ctrl+Shift+I in DualDesk (or call window.dualDesk.openDevTools())
//  to open DevTools for the main renderer. For a specific webview, right-click
//  inside it → "Inspect Element" (only available in dev mode).

console.log('[DualDesk] webview-preload.js loaded — Notification API patched');
