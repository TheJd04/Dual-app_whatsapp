// ─────────────────────────────────────────────────────────────────────────────
//  renderer.js  —  DualDesk renderer process
//
//  Runs in the BrowserWindow's renderer (i.e. in the web page). Has access
//  to the DOM and to window.dualDesk (exposed by preload.js).
//
//  Responsibilities:
//    • Render sidebar icons and handle app selection
//    • Run the split-logo animation sequence
//    • Create, cache, show, and hide <webview> elements per app
//    • Navigation controls (back, forward, reload, logout)
//    • Resizable divider between the two panes
//    • Forward webview notifications to main process
//    • Focus the right pane when a notification is clicked
// ─────────────────────────────────────────────────────────────────────────────

'use strict';

// ─── Chrome UA for webviews ───────────────────────────────────────────────────
//
//  We set this on each <webview> element as well. Main process also injects it
//  at the session level; this is a belt-and-suspenders approach so the very
//  first request definitely uses Chrome's UA.

const IS_MAC  = window.dualDesk?.platform === 'darwin';
const CHROME_UA = IS_MAC
  ? 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
  : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36';

// ─── App configuration ────────────────────────────────────────────────────────

const APPS = {
  whatsapp: {
    name:   'WhatsApp',
    url:    'https://web.whatsapp.com',
    color:  '#25D366',
    badge1Color: '#25D366',
    badge2Color: '#00B4D8',
    labels: ['Personal', 'Business'],
    // SVG icons at two sizes (sidebar = 32px, animation overlay = 108px)
    icon32: `<svg width="32" height="32" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="#25D366"/><path fill="white" d="M50 17C31.8 17 17 31.8 17 50c0 6.4 1.8 12.4 5 17.5L17.5 83 34 78.2c4.9 2.8 10.3 4.3 16 4.3C68.2 82.5 83 67.7 83 49.5 83 31.3 68.2 17 50 17zm.3 60c-5.5 0-10.7-1.5-15-4.2L34 73.5 24 76l2.7-10-1-1.7C23.1 60.5 21.5 55 21.5 50 21.5 34.3 34.3 21.5 50 21.5S78.5 34.3 78.5 50 65.7 77 50.3 77z"/><path fill="white" d="M68 59.1c-.8-.4-4.8-2.4-5.6-2.7-.8-.3-1.3-.4-1.9.5-.6.8-2.2 2.6-2.7 3.2-.5.5-1 .6-1.8.2-.8-.4-3.4-1.3-6.5-4-2.4-2.1-4-4.9-4.5-5.7-.5-.8.1-1.3.4-1.6.3-.3.8-.9 1.2-1.4.4-.5.5-.8.8-1.3.3-.5.1-1-.1-1.4-.2-.4-1.9-4.6-2.6-6.2-.7-1.6-1.4-1.4-1.9-1.4l-1.6-.03c-.5 0-1.4.2-2.2.9-.8.8-3 2.9-3 7s3 7.8 3.4 8.3c.4.5 5.9 9 14.3 12.6 2 .9 3.5 1.4 4.7 1.8 2 .6 3.8.5 5.2.3 1.6-.2 4.8-2 5.5-3.9.7-1.9.7-3.5.5-3.8-.2-.3-.7-.5-1.5-.9z"/></svg>`,
    icon108:`<svg width="108" height="108" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="#25D366"/><path fill="white" d="M50 17C31.8 17 17 31.8 17 50c0 6.4 1.8 12.4 5 17.5L17.5 83 34 78.2c4.9 2.8 10.3 4.3 16 4.3C68.2 82.5 83 67.7 83 49.5 83 31.3 68.2 17 50 17zm.3 60c-5.5 0-10.7-1.5-15-4.2L34 73.5 24 76l2.7-10-1-1.7C23.1 60.5 21.5 55 21.5 50 21.5 34.3 34.3 21.5 50 21.5S78.5 34.3 78.5 50 65.7 77 50.3 77z"/><path fill="white" d="M68 59.1c-.8-.4-4.8-2.4-5.6-2.7-.8-.3-1.3-.4-1.9.5-.6.8-2.2 2.6-2.7 3.2-.5.5-1 .6-1.8.2-.8-.4-3.4-1.3-6.5-4-2.4-2.1-4-4.9-4.5-5.7-.5-.8.1-1.3.4-1.6.3-.3.8-.9 1.2-1.4.4-.5.5-.8.8-1.3.3-.5.1-1-.1-1.4-.2-.4-1.9-4.6-2.6-6.2-.7-1.6-1.4-1.4-1.9-1.4l-1.6-.03c-.5 0-1.4.2-2.2.9-.8.8-3 2.9-3 7s3 7.8 3.4 8.3c.4.5 5.9 9 14.3 12.6 2 .9 3.5 1.4 4.7 1.8 2 .6 3.8.5 5.2.3 1.6-.2 4.8-2 5.5-3.9.7-1.9.7-3.5.5-3.8-.2-.3-.7-.5-1.5-.9z"/></svg>`,
  },
  instagram: {
    name:   'Instagram',
    url:    'https://www.instagram.com',
    color:  '#E1306C',
    badge1Color: '#E1306C',
    badge2Color: '#833AB4',
    labels: ['Main', 'Creator'],
    icon32: `<svg width="32" height="32" viewBox="0 0 100 100"><defs><linearGradient id="ig32" x1="0%" y1="100%" x2="100%" y2="0%"><stop offset="0%" stop-color="#FFDB2C"/><stop offset="25%" stop-color="#FF943E"/><stop offset="50%" stop-color="#F2335B"/><stop offset="75%" stop-color="#CD2F93"/><stop offset="100%" stop-color="#6C56F2"/></linearGradient></defs><rect width="100" height="100" rx="22" fill="url(#ig32)"/><rect x="14" y="14" width="72" height="72" rx="19" fill="none" stroke="white" stroke-width="7"/><circle cx="50" cy="50" r="19" fill="none" stroke="white" stroke-width="7"/><circle cx="74" cy="26" r="6" fill="white"/></svg>`,
    icon108:`<svg width="108" height="108" viewBox="0 0 100 100"><defs><linearGradient id="ig108" x1="0%" y1="100%" x2="100%" y2="0%"><stop offset="0%" stop-color="#FFDB2C"/><stop offset="25%" stop-color="#FF943E"/><stop offset="50%" stop-color="#F2335B"/><stop offset="75%" stop-color="#CD2F93"/><stop offset="100%" stop-color="#6C56F2"/></linearGradient></defs><rect width="100" height="100" rx="22" fill="url(#ig108)"/><rect x="14" y="14" width="72" height="72" rx="19" fill="none" stroke="white" stroke-width="7"/><circle cx="50" cy="50" r="19" fill="none" stroke="white" stroke-width="7"/><circle cx="74" cy="26" r="6" fill="white"/></svg>`,
  },
  snapchat: {
    name:   'Snapchat',
    url:    'https://web.snapchat.com',
    color:  '#FFFC00',
    badge1Color: '#FFFC00',
    badge2Color: '#FF6900',
    labels: ['Personal', 'Public'],
    icon32: `<svg width="32" height="32" viewBox="0 0 100 100"><rect width="100" height="100" rx="22" fill="#FFFC00"/><path fill="#000" d="M50 20c-5 0-15 2.5-15 18v4c-1 .6-2.2.9-3.5.9-1.3 0-2.5-.8-2.5-.8s-.3 4.5 3.5 5.9c0 0-.5 5.5 6 9.5 0 0-2 1.2-2 3.5s4.5 3.5 8 3.5c0 0 2.5 4.5 5.5 4.5s5.5-4.5 5.5-4.5c3.5 0 8-1.2 8-3.5s-2-3.5-2-3.5c6.5-4 6-9.5 6-9.5 3.8-1.4 3.5-5.9 3.5-5.9s-1.2.8-2.5.8c-1.3 0-2.5-.3-3.5-.9v-4c0-15.5-10-18-15-18z"/></svg>`,
    icon108:`<svg width="108" height="108" viewBox="0 0 100 100"><rect width="100" height="100" rx="22" fill="#FFFC00"/><path fill="#000" d="M50 20c-5 0-15 2.5-15 18v4c-1 .6-2.2.9-3.5.9-1.3 0-2.5-.8-2.5-.8s-.3 4.5 3.5 5.9c0 0-.5 5.5 6 9.5 0 0-2 1.2-2 3.5s4.5 3.5 8 3.5c0 0 2.5 4.5 5.5 4.5s5.5-4.5 5.5-4.5c3.5 0 8-1.2 8-3.5s-2-3.5-2-3.5c6.5-4 6-9.5 6-9.5 3.8-1.4 3.5-5.9 3.5-5.9s-1.2.8-2.5.8c-1.3 0-2.5-.3-3.5-.9v-4c0-15.5-10-18-15-18z"/></svg>`,
  },
  netflix: {
    name:   'Netflix',
    url:    'https://www.netflix.com',
    color:  '#E50914',
    badge1Color: '#E50914',
    badge2Color: '#B20710',
    labels: ['Home', 'Work'],
    icon32: `<svg width="32" height="32" viewBox="0 0 100 100"><rect width="100" height="100" rx="12" fill="#141414"/><path fill="#E50914" d="M24 18h17l17 54V18h18v64h-17L42 28v54H24z"/></svg>`,
    icon108:`<svg width="108" height="108" viewBox="0 0 100 100"><rect width="100" height="100" rx="12" fill="#141414"/><path fill="#E50914" d="M24 18h17l17 54V18h18v64h-17L42 28v54H24z"/></svg>`,
  },
  prime: {
    name:   'Prime Video',
    url:    'https://www.primevideo.com',
    color:  '#00A8E0',
    badge1Color: '#00A8E0',
    badge2Color: '#0077A8',
    labels: ['Account 1', 'Account 2'],
    icon32: `<svg width="32" height="32" viewBox="0 0 100 100"><rect width="100" height="100" rx="12" fill="#232F3E"/><text x="8" y="56" font-size="25" font-weight="700" font-family="Arial,sans-serif" fill="#fff">prime</text><path d="M8 75 Q50 88 92 75" stroke="#00A8E0" stroke-width="3" fill="none" stroke-linecap="round"/></svg>`,
    icon108:`<svg width="108" height="108" viewBox="0 0 100 100"><rect width="100" height="100" rx="12" fill="#232F3E"/><text x="6" y="52" font-size="24" font-weight="700" font-family="Arial,sans-serif" fill="#fff">prime</text><text x="6" y="70" font-size="16" font-family="Arial,sans-serif" fill="#00A8E0">video</text><path d="M6 80 Q50 93 94 80" stroke="#00A8E0" stroke-width="3.5" fill="none" stroke-linecap="round"/></svg>`,
  },
};

const APP_ORDER = ['whatsapp', 'instagram', 'snapchat', 'netflix', 'prime'];

// ─── Animation constants ──────────────────────────────────────────────────────

const LS   = 108;    // logo size in px during animation
const EASE = 'cubic-bezier(.25,.46,.45,.94)';

// Phase timing (ms from when selectApp() is called)
const T_LOGO_APPEAR  =   60;   // start: logo scales in
const T_SPLITTING    =  760;   // cut line appears
const T_SEPARATING   = 1160;   // halves fly apart
const T_ACTIVE       = 2260;   // show real webviews

// ─── State ────────────────────────────────────────────────────────────────────

let currentApp   = null;    // e.g. 'whatsapp'
let currentPhase = 'idle';  // idle | logo-appear | splitting | separating | active
let animTimers   = [];      // setTimeout IDs for the animation sequence

/** Cache of created webview pairs: { appId: [webview1, webview2] } */
const webviewCache = {};

// ─── DOM refs ─────────────────────────────────────────────────────────────────

const $welcome  = document.getElementById('welcome');
const $overlay  = document.getElementById('anim-overlay');
const $panes    = document.getElementById('panes');
const $loading  = document.getElementById('loading-overlay');
const $wrapL    = document.getElementById('wrap-left');
const $wrapR    = document.getElementById('wrap-right');
const $badgeL   = document.getElementById('badge-left');
const $badgeR   = document.getElementById('badge-right');
const $urlL     = document.getElementById('url-left');
const $urlR     = document.getElementById('url-right');

// ─────────────────────────────────────────────────────────────────────────────
//  Sidebar setup
// ─────────────────────────────────────────────────────────────────────────────

function buildSidebar() {
  const container = document.getElementById('app-icons');

  APP_ORDER.forEach(appId => {
    const app = APPS[appId];
    const btn = document.createElement('button');
    btn.className   = 'app-btn';
    btn.id          = `btn-${appId}`;
    btn.title       = app.name;
    btn.setAttribute('aria-label', app.name);
    btn.innerHTML   = `
      ${app.icon32}
      <span class="app-btn-label">${app.name.replace(' Video', '')}</span>
      <div class="active-dot" id="dot-${appId}" hidden></div>`;
    btn.addEventListener('click', () => selectApp(appId));
    container.appendChild(btn);
  });

  // Welcome screen icon row
  const welcomeIcons = document.getElementById('welcome-icons');
  APP_ORDER.forEach(appId => {
    const div = document.createElement('div');
    div.innerHTML = APPS[appId].icon32;
    welcomeIcons.appendChild(div);
  });

  // Add-app button
  document.getElementById('add-btn').addEventListener('click', () => {
    alert('Custom app support is coming in a future update.\n\nFor now, click any of the 5 apps on the left to get started.');
  });

  // DevTools button
  document.getElementById('devtools-btn').addEventListener('click', () => {
    window.dualDesk?.openDevTools();
  });
}

function updateSidebarSelection(appId) {
  APP_ORDER.forEach(id => {
    const btn = document.getElementById(`btn-${id}`);
    const dot = document.getElementById(`dot-${id}`);
    if (btn) btn.classList.toggle('active', id === appId);
    if (dot) {
      dot.hidden = (id !== appId || currentPhase !== 'active');
      if (!dot.hidden) dot.style.background = APPS[id].color;
    }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
//  Phase transitions
// ─────────────────────────────────────────────────────────────────────────────

function clearAnimTimers() {
  animTimers.forEach(clearTimeout);
  animTimers = [];
}

function T(fn, ms) {
  animTimers.push(setTimeout(fn, ms));
}

function setPhase(phase) {
  currentPhase = phase;

  $welcome.hidden  = (phase !== 'idle');
  $overlay.hidden  = (phase === 'idle' || phase === 'active');
  $panes.hidden    = (phase !== 'active');

  if (phase === 'logo-appear') renderLogoAppear();
  if (phase === 'splitting')   renderSplitting();
  if (phase === 'separating')  renderSeparating();
  if (phase === 'active')      activatePanes();

  updateSidebarSelection(currentApp);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Main entry: selecting an app
// ─────────────────────────────────────────────────────────────────────────────

function selectApp(appId) {
  // Tapping the same active app does nothing
  if (currentApp === appId && currentPhase === 'active') return;

  clearAnimTimers();

  // Start loading webviews immediately in the background
  // (they will be hidden under the animation overlay)
  getOrCreateWebviews(appId);

  // Brief reset to idle so we get a clean slate
  currentApp = appId;
  setPhase('idle');

  // Kick off the timed animation sequence
  T(() => setPhase('logo-appear'), T_LOGO_APPEAR);
  T(() => setPhase('splitting'),   T_SPLITTING);
  T(() => setPhase('separating'),  T_SEPARATING);
  T(() => setPhase('active'),      T_ACTIVE);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Animation — phase renderers
// ─────────────────────────────────────────────────────────────────────────────

function renderLogoAppear() {
  const app = APPS[currentApp];
  $overlay.innerHTML = `
    <div class="anim-glow" style="background:radial-gradient(circle,${app.color}22 0%,transparent 70%)"></div>
    <div class="anim-logo-wrap" style="animation:ddLogoIn .55s ease both;opacity:0">
      ${app.icon108}
    </div>
    <div class="anim-app-name" style="animation:ddLogoIn .7s .2s ease both;opacity:0">${app.name}</div>`;
}

function renderSplitting() {
  const app = APPS[currentApp];

  // Render the two-half structure. Halves start at translate(0,0) — visually
  // identical to the full logo. The cut line animates in via CSS.
  $overlay.innerHTML = `
    <div class="anim-glow" style="background:radial-gradient(circle,${app.color}22 0%,transparent 70%)"></div>
    <div id="anim-halves" style="position:relative;width:${LS}px;height:${LS}px">

      <!-- Top half: shows top 54px of the logo via overflow:hidden -->
      <div id="anim-top"
           style="position:absolute;top:0;left:0;
                  width:${LS}px;height:${LS/2}px;overflow:hidden;
                  transition:transform 1s ${EASE};
                  transform:translate(0,0) scale(1);
                  transform-origin:bottom center">
        ${app.icon108}
      </div>

      <!-- Cut line — grows from center outward via cutGrow keyframe -->
      <div id="anim-cut"
           style="position:absolute;
                  top:${LS/2 - 1.5}px;left:-18px;right:-18px;height:3px;
                  background:linear-gradient(90deg,transparent,${app.color},white,${app.color},transparent);
                  box-shadow:0 0 10px ${app.color},0 0 22px ${app.color}55;
                  animation:ddCutGrow .35s ease forwards;
                  transform-origin:center"></div>

      <!-- Bottom half: shows bottom 54px via negative margin-top -->
      <div id="anim-bot"
           style="position:absolute;top:${LS/2}px;left:0;
                  width:${LS}px;height:${LS/2}px;overflow:hidden;
                  transition:transform 1s ${EASE};
                  transform:translate(0,0) scale(1);
                  transform-origin:top center">
        <div style="margin-top:-${LS/2}px">${app.icon108}</div>
      </div>

    </div>
    <div class="anim-app-name" style="opacity:.3">${app.name}</div>`;
}

function renderSeparating() {
  // The halves are already in the DOM from renderSplitting().
  // Updating transform triggers the CSS transition (1s cubic-bezier).
  // Top half → upper right; bottom half → lower left.
  const top = document.getElementById('anim-top');
  const bot = document.getElementById('anim-bot');
  if (top) top.style.transform = 'translate(240px,-130px) scale(.45)';
  if (bot) bot.style.transform = 'translate(-240px,130px) scale(.45)';
}

// ─────────────────────────────────────────────────────────────────────────────
//  Pane activation — shows the real webviews
// ─────────────────────────────────────────────────────────────────────────────

function activatePanes() {
  const app = APPS[currentApp];

  // Update account labels and badge colours
  $badgeL.textContent = app.labels[0];
  $badgeR.textContent = app.labels[1];
  $badgeL.style.background = app.badge1Color;
  $badgeR.style.background = app.badge2Color;
  $badgeL.style.color = app.color === '#FFFC00' ? '#000' : '#fff';
  $badgeR.style.color = '#fff';

  // Show only this app's webview pair; hide all others
  showWebviews(currentApp);

  // Update dot in sidebar now that we're active
  const dot = document.getElementById(`dot-${currentApp}`);
  if (dot) {
    dot.hidden = false;
    dot.style.background = app.color;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Webview management
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Get the existing webview pair for appId, or create them if this is the
 * first time this app has been selected.
 */
function getOrCreateWebviews(appId) {
  if (webviewCache[appId]) return webviewCache[appId];

  const app  = APPS[appId];
  const wvL  = createWebview(appId, 1);
  const wvR  = createWebview(appId, 2);

  // Hidden by default; showWebviews() makes the active pair visible
  wvL.style.display = 'none';
  wvR.style.display = 'none';

  $wrapL.appendChild(wvL);
  $wrapR.appendChild(wvR);

  webviewCache[appId] = [wvL, wvR];
  return [wvL, wvR];
}

/**
 * Create a single <webview> element with the correct partition, UA, and
 * preload script wired up.
 *
 * @param {string} appId      e.g. 'whatsapp'
 * @param {1|2}    slot       1 = left pane (Account 1), 2 = right pane (Account 2)
 */
function createWebview(appId, slot) {
  const partition = `persist:${appId}-${slot}`;
  const app       = APPS[appId];
  const wv        = document.createElement('webview');

  // ── Core attributes ────────────────────────────────────────────────────
  wv.setAttribute('src',       app.url);
  wv.setAttribute('partition', partition);
  wv.setAttribute('useragent', CHROME_UA);

  // Allow popup windows (needed for OAuth flows, media viewers, etc.)
  wv.setAttribute('allowpopups', '');

  // Inject our notification interceptor into the webview's renderer
  if (window.dualDesk?.webviewPreloadUrl) {
    wv.setAttribute('preload', window.dualDesk.webviewPreloadUrl);
  }

  // Fill the parent container completely
  wv.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;';

  // ── Event listeners ────────────────────────────────────────────────────

  // Forward web Notifications to main process → native OS notification
  wv.addEventListener('ipc-message', (event) => {
    if (event.channel === 'webview:notification') {
      window.dualDesk?.sendNotification({
        ...event.args[0],
        partition,
      });
    }
  });

  // Update URL display in the nav bar when navigation occurs
  wv.addEventListener('did-navigate',         () => updateUrlBar(appId));
  wv.addEventListener('did-navigate-in-page', () => updateUrlBar(appId));
  wv.addEventListener('page-title-updated',   () => updateUrlBar(appId));

  // Show a loading spinner while the page first loads
  wv.addEventListener('did-start-loading', () => {
    if (currentApp === appId && currentPhase === 'active') showLoadingOverlay(true);
  });
  wv.addEventListener('did-stop-loading', () => {
    showLoadingOverlay(false);
  });

  // Log navigation errors (don't crash the app)
  wv.addEventListener('did-fail-load', (e) => {
    if (e.errorCode !== -3) { // -3 is ERR_ABORTED (normal for redirects)
      console.warn(`[webview] ${appId}-${slot} load failed:`, e.errorDescription, e.validatedURL);
    }
    showLoadingOverlay(false);
  });

  // Crash recovery: if the webview process crashes, reload it
  wv.addEventListener('crashed', () => {
    console.error(`[webview] ${appId}-${slot} crashed — reloading`);
    setTimeout(() => wv.reload(), 1000);
  });

  return wv;
}

/** Make only the given app's webviews visible; hide everything else. */
function showWebviews(appId) {
  Object.entries(webviewCache).forEach(([id, [wv1, wv2]]) => {
    const visible = (id === appId);
    wv1.style.display = visible ? 'block' : 'none';
    wv2.style.display = visible ? 'block' : 'none';
  });
}

/** Return the current app's [leftWebview, rightWebview], or [null, null]. */
function getCurrentWebviews() {
  if (!currentApp) return [null, null];
  return webviewCache[currentApp] || [null, null];
}

// ─── URL bar ──────────────────────────────────────────────────────────────────

function updateUrlBar(appId) {
  if (appId !== currentApp) return;
  const [wv1, wv2] = getCurrentWebviews();
  try {
    if (wv1) $urlL.textContent = new URL(wv1.getURL()).hostname;
  } catch { $urlL.textContent = ''; }
  try {
    if (wv2) $urlR.textContent = new URL(wv2.getURL()).hostname;
  } catch { $urlR.textContent = ''; }
}

// ─── Loading overlay ─────────────────────────────────────────────────────────

function showLoadingOverlay(show) {
  $loading.hidden = !show;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Navigation controls (back / forward / reload / logout)
// ─────────────────────────────────────────────────────────────────────────────

function setupNavControls() {
  // ── Left pane ────────────────────────────────────────────────────────────
  document.getElementById('back-left').addEventListener('click', () => {
    const [wv] = getCurrentWebviews();
    if (wv && wv.canGoBack()) wv.goBack();
  });
  document.getElementById('fwd-left').addEventListener('click', () => {
    const [wv] = getCurrentWebviews();
    if (wv && wv.canGoForward()) wv.goForward();
  });
  document.getElementById('reload-left').addEventListener('click', () => {
    const [wv] = getCurrentWebviews();
    if (wv) wv.reload();
  });

  // ── Right pane ───────────────────────────────────────────────────────────
  document.getElementById('back-right').addEventListener('click', () => {
    const [, wv] = getCurrentWebviews();
    if (wv && wv.canGoBack()) wv.goBack();
  });
  document.getElementById('fwd-right').addEventListener('click', () => {
    const [, wv] = getCurrentWebviews();
    if (wv && wv.canGoForward()) wv.goForward();
  });
  document.getElementById('reload-right').addEventListener('click', () => {
    const [, wv] = getCurrentWebviews();
    if (wv) wv.reload();
  });

  // ── Logout ───────────────────────────────────────────────────────────────
  document.getElementById('logout-left').addEventListener('click', () => logout(1));
  document.getElementById('logout-right').addEventListener('click', () => logout(2));
}

async function logout(slot) {
  if (!currentApp) return;
  const app       = APPS[currentApp];
  const label     = app.labels[slot - 1];
  const partition = `persist:${currentApp}-${slot}`;

  const confirmed = confirm(
    `Log out of your ${label} ${app.name} account?\n\nThis will clear all cookies and local data for this account. You will need to scan the QR code again.`
  );
  if (!confirmed) return;

  // Clear the session data in the main process
  const result = await window.dualDesk?.clearSession(partition);
  if (result?.ok) {
    // Reload the webview so it shows the login screen again
    const [wv1, wv2] = getCurrentWebviews();
    const wv = slot === 1 ? wv1 : wv2;
    if (wv) {
      wv.loadURL(app.url);
      console.log(`[renderer] Logged out of ${partition}`);
    }
  } else {
    alert(`Logout failed: ${result?.error || 'Unknown error'}`);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Resizable divider
// ─────────────────────────────────────────────────────────────────────────────

function setupDivider() {
  const divider   = document.getElementById('divider');
  const paneLeft  = document.getElementById('pane-left');
  const paneRight = document.getElementById('pane-right');
  const panesEl   = document.getElementById('panes');

  let dragging      = false;
  let startX        = 0;
  let startLeftW    = 0;

  divider.addEventListener('mousedown', (e) => {
    dragging    = true;
    startX      = e.clientX;
    startLeftW  = paneLeft.getBoundingClientRect().width;

    document.body.style.cursor      = 'col-resize';
    document.body.style.userSelect  = 'none';

    // Disable pointer events on webviews while dragging
    // (webviews eat mouse events otherwise)
    document.querySelectorAll('webview').forEach(wv => {
      wv.style.pointerEvents = 'none';
    });

    e.preventDefault();
  });

  document.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    const dx         = e.clientX - startX;
    const totalW     = panesEl.getBoundingClientRect().width - divider.offsetWidth;
    const minPane    = 300;
    const newLeftW   = Math.max(minPane, Math.min(startLeftW + dx, totalW - minPane));
    const newRightW  = totalW - newLeftW;

    paneLeft.style.flex  = 'none';
    paneLeft.style.width = `${newLeftW}px`;
    paneRight.style.flex  = 'none';
    paneRight.style.width = `${newRightW}px`;
  });

  document.addEventListener('mouseup', () => {
    if (!dragging) return;
    dragging = false;
    document.body.style.cursor     = '';
    document.body.style.userSelect = '';
    document.querySelectorAll('webview').forEach(wv => {
      wv.style.pointerEvents = '';
    });
  });

  // Double-click divider to reset to 50/50
  divider.addEventListener('dblclick', () => {
    paneLeft.style.flex  = '1';
    paneLeft.style.width = '';
    paneRight.style.flex  = '1';
    paneRight.style.width = '';
  });
}

// ─────────────────────────────────────────────────────────────────────────────
//  Notification focus — when user clicks an OS notification
// ─────────────────────────────────────────────────────────────────────────────

function setupNotificationFocus() {
  window.dualDesk?.onNotificationFocus((partition) => {
    // Figure out which side this notification came from
    if (!currentApp) return;
    const isLeft = partition === `persist:${currentApp}-1`;

    // Briefly flash the relevant pane to show the user where the message is
    const flashEl = document.getElementById('notif-flash');
    if (!flashEl) return;
    flashEl.style.left   = isLeft ? '76px'  : '50%';
    flashEl.style.width  = isLeft ? 'calc(50% - 38px)' : '50%';
    flashEl.hidden = false;
    setTimeout(() => { flashEl.hidden = true; }, 600);
  });
}

// ─────────────────────────────────────────────────────────────────────────────
//  Keyboard shortcuts
// ─────────────────────────────────────────────────────────────────────────────

function setupKeyboard() {
  document.addEventListener('keydown', (e) => {
    const mod = IS_MAC ? e.metaKey : e.ctrlKey;

    // Cmd/Ctrl + 1-5 → select app by index
    if (mod && e.key >= '1' && e.key <= '5') {
      const idx = parseInt(e.key, 10) - 1;
      if (APP_ORDER[idx]) selectApp(APP_ORDER[idx]);
    }

    // Cmd/Ctrl + R → reload both panes
    if (mod && e.key === 'r') {
      const [wv1, wv2] = getCurrentWebviews();
      if (wv1) wv1.reload();
      if (wv2) wv2.reload();
      e.preventDefault();
    }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
//  Initialise
// ─────────────────────────────────────────────────────────────────────────────

function init() {
  buildSidebar();
  setupNavControls();
  setupDivider();
  setupNotificationFocus();
  setupKeyboard();

  // If no dualDesk bridge (running in a regular browser for testing),
  // show a warning but don't crash
  if (!window.dualDesk) {
    console.warn('[renderer] window.dualDesk not available — running outside Electron?');
  }

  console.log('[renderer] DualDesk ready');
}

init();
