// ─────────────────────────────────────────────────────────────────────────────
//  DualDesk — main.js  (Electron main process / backend)
//
//  This file is the heart of the app. It runs in Node.js (not in the browser)
//  and is responsible for:
//    • Creating and managing the BrowserWindow
//    • Configuring isolated sessions (one per account slot)
//    • Injecting a Chrome User-Agent so web apps don't reject us
//    • Granting browser permissions (notifications, camera, mic)
//    • Forwarding webview notifications to native OS notifications
//    • Handling logout (clearing cookies / localStorage)
//    • Securing the app against common Electron attack vectors
// ─────────────────────────────────────────────────────────────────────────────

'use strict';

const {
  app,
  BrowserWindow,
  ipcMain,
  session,
  Notification,
  nativeImage,
  shell,
  Menu,
} = require('electron');

const path = require('path');
const os   = require('os');

// ─── Platform helpers ─────────────────────────────────────────────────────────

const IS_MAC  = os.platform() === 'darwin';
const IS_WIN  = os.platform() === 'win32';
const IS_DEV  = process.env.NODE_ENV === 'development';

// ─── Chrome User-Agent ────────────────────────────────────────────────────────
//
//  WhatsApp Web, Instagram, and most social apps block Electron's default UA.
//  We override it to look like a normal Chrome browser so they load correctly.
//  The override is applied at the session level so every request from every
//  webview automatically uses it — no per-webview configuration needed.

const CHROME_UA = IS_MAC
  ? 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
  : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36';

// ─── App IDs ──────────────────────────────────────────────────────────────────
//
//  Each app gets two session partitions: persist:<appId>-1 and persist:<appId>-2
//  "persist:" means the session is saved to disk between launches, so users
//  stay logged in. Removing "persist:" would make sessions memory-only.

const APP_IDS = ['whatsapp', 'instagram', 'snapchat', 'netflix', 'prime'];

// ─────────────────────────────────────────────────────────────────────────────
//  Session configuration
//  Called once for every partition (10 total: 5 apps × 2 slots).
//  Sets the UA header and auto-grants browser permissions.
// ─────────────────────────────────────────────────────────────────────────────

function configureSession(partitionName) {
  const ses = session.fromPartition(partitionName, { cache: true });

  // ── User-Agent override ──────────────────────────────────────────────────
  //
  //  Intercepts every outgoing HTTP/HTTPS request and replaces the UA header
  //  before it leaves the machine. This is the most reliable way to do it
  //  (as opposed to setting it on individual webContents) because it applies
  //  to navigation requests, XHR/fetch, service workers, etc.

  ses.webRequest.onBeforeSendHeaders((details, callback) => {
    details.requestHeaders['User-Agent'] = CHROME_UA;
    // Remove the Electron "sec-ch-ua" header that can reveal we're Electron
    delete details.requestHeaders['sec-ch-ua'];
    delete details.requestHeaders['sec-ch-ua-mobile'];
    delete details.requestHeaders['sec-ch-ua-platform'];
    callback({ requestHeaders: details.requestHeaders });
  });

  // ── Permission handler ───────────────────────────────────────────────────
  //
  //  Web apps call requestPermission() for things like push notifications,
  //  camera access, clipboard. We auto-grant the safe ones. Others (like
  //  geolocation or microphone) are denied unless listed here.

  ses.setPermissionRequestHandler((_webContents, permission, callback) => {
    const GRANTED = [
      'notifications',            // Push notifications (WhatsApp, Instagram)
      'media',                    // Camera / microphone for calls
      'clipboard-read',           // Clipboard paste
      'clipboard-sanitized-write',// Clipboard copy
      'fullscreen',               // Full-screen video
      'pointerLock',              // Mouse lock (some apps need it)
    ];
    callback(GRANTED.includes(permission));
  });

  // ── Permission check handler ─────────────────────────────────────────────
  //
  //  Some APIs (e.g. Notification.permission) query the current state
  //  synchronously. We return true for the same safe set.

  ses.setPermissionCheckHandler((_webContents, permission) => {
    const ALWAYS_OK = ['notifications', 'media', 'clipboard-read'];
    return ALWAYS_OK.includes(permission);
  });

  // ── Certificate errors ───────────────────────────────────────────────────
  //
  //  By default Electron blocks invalid TLS certificates. Keep that behaviour
  //  (no override here) — we only load first-party web apps that have valid certs.

  return ses;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Window creation
// ─────────────────────────────────────────────────────────────────────────────

let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    // ── Size ────────────────────────────────────────────────────────────────
    width:     1440,
    height:    900,
    minWidth:  960,
    minHeight: 620,

    // ── Title bar ────────────────────────────────────────────────────────────
    //
    //  macOS: "hiddenInset" hides the default title text but keeps the native
    //  traffic-light (●●●) buttons in the top-left corner. We draw our own
    //  draggable area with CSS (-webkit-app-region: drag).
    //
    //  Windows / Linux: use the OS default frame. The user gets the familiar
    //  minimize/maximize/close buttons. Simpler and more reliable.

    titleBarStyle: IS_MAC ? 'hiddenInset' : 'default',
    frame: true,

    // ── Web preferences ──────────────────────────────────────────────────────
    webPreferences: {
      // Security: renderer cannot use Node.js APIs directly
      nodeIntegration: false,

      // Security: renderer lives in its own JS context (worlds are separate)
      contextIsolation: true,

      // We use a preload script to bridge main ↔ renderer safely.
      // sandbox: false lets the preload use require() (needed for ipcRenderer).
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),

      // This is what makes <webview> tags work in the renderer HTML.
      // Each <webview> gets its own renderer process with its own session.
      webviewTag: true,

      // Allow spell-check in text inputs inside webviews
      spellcheck: true,
    },

    // Prevents a flash of white before the dark UI paints
    backgroundColor: '#0A0D13',

    // We call mainWindow.show() ourselves (in ready-to-show) to avoid that flash
    show: false,
  });

  // Load the renderer HTML
  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  // Show the window once the first paint is ready (no white flash)
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (IS_DEV) {
      mainWindow.webContents.openDevTools({ mode: 'detach' });
    }
  });

  // Remove the native menu bar on Windows/Linux (we have the sidebar instead)
  if (!IS_MAC) {
    mainWindow.setMenuBarVisibility(false);
    Menu.setApplicationMenu(null);
  }

  // Prevent the main window from navigating away from index.html
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith('file://')) {
      event.preventDefault();
      console.warn('[main] Blocked navigation to:', url);
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// ─────────────────────────────────────────────────────────────────────────────
//  IPC: Session management
//  Called from renderer when the user clicks "Log out" on a pane.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Clear all stored data for one account slot.
 * After this, the webview will show the login/QR-scan screen again.
 */
ipcMain.handle('session:clear', async (_event, partitionName) => {
  try {
    const ses = session.fromPartition(partitionName);
    await ses.clearStorageData({
      storages: [
        'cookies',
        'localstorage',
        'indexdb',
        'cachestorage',
        'serviceworkers',
        'filesystems',
      ],
    });
    console.log('[session:clear]', partitionName, '— cleared');
    return { ok: true };
  } catch (err) {
    console.error('[session:clear]', err.message);
    return { ok: false, error: err.message };
  }
});

/**
 * Returns true if a partition already has cookies (user is logged in).
 * Used by the renderer to show a "returning user" hint in the UI.
 */
ipcMain.handle('session:has-cookies', async (_event, partitionName) => {
  try {
    const ses = session.fromPartition(partitionName);
    const cookies = await ses.cookies.get({});
    return cookies.length > 0;
  } catch {
    return false;
  }
});

// ─────────────────────────────────────────────────────────────────────────────
//  IPC: Native notifications
//
//  When a webview intercepts a Web Notification (e.g. WhatsApp message),
//  it sends an IPC message to the renderer → renderer forwards it here →
//  we show a proper OS-level notification with click-to-focus.
// ─────────────────────────────────────────────────────────────────────────────

ipcMain.on('webview:notification', (_event, { title, body, icon, partition }) => {
  if (!Notification.isSupported()) return;

  const opts = {
    title: title  || 'DualDesk',
    body:  body   || '',
    urgency: 'normal',
  };

  // If the web app provided an icon (usually a data: URL), convert it
  if (icon && icon.startsWith('data:')) {
    try {
      opts.icon = nativeImage.createFromDataURL(icon);
    } catch { /* ignore bad icon data */ }
  }

  const notif = new Notification(opts);

  // Clicking the OS notification brings DualDesk to front
  // and tells the renderer which pane to highlight
  notif.on('click', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
      // Tell renderer to visually highlight the pane this notification came from
      mainWindow.webContents.send('notification:focus', partition);
    }
  });

  notif.show();
});

// ─────────────────────────────────────────────────────────────────────────────
//  IPC: Window controls
//
//  The renderer's custom title-bar buttons (macOS inset area, or our own
//  buttons on Windows) send these messages instead of having direct access
//  to the Electron BrowserWindow API.
// ─────────────────────────────────────────────────────────────────────────────

ipcMain.on('window:minimize', () => mainWindow?.minimize());

ipcMain.on('window:maximize', () => {
  if (!mainWindow) return;
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
});

ipcMain.on('window:close', () => mainWindow?.close());

// ─────────────────────────────────────────────────────────────────────────────
//  IPC: Developer tools
// ─────────────────────────────────────────────────────────────────────────────

ipcMain.on('devtools:open', () => {
  mainWindow?.webContents.openDevTools({ mode: 'detach' });
});

// ─────────────────────────────────────────────────────────────────────────────
//  Security: handle new windows opened by webviews
//
//  Some web apps (e.g. OAuth popups) call window.open() or use target="_blank".
//  Instead of opening a new Electron window (which would lack proper session
//  isolation), we redirect to the user's default browser.
//  Exception: WhatsApp sometimes opens sub-windows for media — we allow those.
// ─────────────────────────────────────────────────────────────────────────────

app.on('web-contents-created', (_event, webContents) => {
  webContents.setWindowOpenHandler(({ url }) => {
    // Open external links in the system browser
    if (url.startsWith('https://') || url.startsWith('http://')) {
      shell.openExternal(url);
    }
    // Deny new Electron windows
    return { action: 'deny' };
  });

  // Block renderer-level navigation to external URLs
  // (webviews navigating within the same web app is fine)
  webContents.on('will-navigate', (_navEvent, url) => {
    // Allow navigation within the same origin — web apps do this all the time
    // Block if it somehow tries to load a different scheme
    if (url.startsWith('javascript:')) {
      _navEvent.preventDefault();
    }
  });
});

// ─────────────────────────────────────────────────────────────────────────────
//  App lifecycle
// ─────────────────────────────────────────────────────────────────────────────

app.whenReady().then(() => {
  // ── Pre-configure all sessions ───────────────────────────────────────────
  //
  //  We set up the UA override and permissions before any webview loads,
  //  so the very first request already has the right headers.
  //  Without this, the first navigation might slip through with Electron's UA.

  APP_IDS.forEach(appId => {
    configureSession(`persist:${appId}-1`);
    configureSession(`persist:${appId}-2`);
  });

  // Create the main window
  createWindow();

  // macOS: clicking the dock icon when no windows are open re-creates the window
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

// Windows / Linux: quit when all windows are closed
app.on('window-all-closed', () => {
  if (!IS_MAC) app.quit();
});

// Catch unhandled errors in the main process and log them
process.on('uncaughtException', (err) => {
  console.error('[main] Uncaught exception:', err);
});

process.on('unhandledRejection', (reason) => {
  console.error('[main] Unhandled rejection:', reason);
});
